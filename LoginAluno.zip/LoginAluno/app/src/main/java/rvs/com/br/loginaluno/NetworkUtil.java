package rvs.com.br.loginaluno;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Map;

public class NetworkUtil {

    private static final int TIME_OUT = 60000;

    public static WsResponse sendPost(String url, Map<String,Object> params){
        WsResponse retorno = new WsResponse();
        try {
            URL apiEnd = new URL(url);
            int codigoResposta;
            HttpURLConnection conexao;
            InputStream is;

            conexao = (HttpURLConnection) apiEnd.openConnection();
            conexao.setRequestMethod("POST");
            conexao.setReadTimeout(TIME_OUT);
            conexao.setConnectTimeout(TIME_OUT);
            conexao.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conexao.setDoOutput(true);

            JSONObject urlParameters = new JSONObject();

            for (String key : params.keySet()) {
                urlParameters.put(key, params.get(key));
            }

            OutputStream os = conexao.getOutputStream();
            os.write(urlParameters.toString().getBytes("UTF-8"));
            os.close();

            codigoResposta = conexao.getResponseCode();

            if (codigoResposta < HttpURLConnection.HTTP_BAD_REQUEST) {
                is = conexao.getInputStream();
            } else {
                is = conexao.getErrorStream();
            }

            if (codigoResposta == HttpURLConnection.HTTP_NOT_FOUND) {
                retorno.setMsg("URL do webservice incorreta");
                retorno.setStatus(false);
            } else {
                String strRet = converterInputStreamToString(is);
                is.close();
                conexao.disconnect();

                JSONObject jsonResponse = new JSONObject(strRet);
                retorno.setStatus(jsonResponse.getBoolean("status"));
                retorno.setMsg(jsonResponse.getString("msg"));
            }
        }catch (UnknownHostException e) {
            retorno.setStatus(false);
            retorno.setMsg("URL do webservice incorreta");
        }catch (MalformedURLException e){
            retorno.setStatus(false);
            retorno.setMsg("URL do webservice incorreta");
        }catch (SocketTimeoutException e){
            e.printStackTrace();
            retorno.setStatus(false);
            retorno.setMsg("A conexão com o servidor excedeu o tempo limite. Verifique sua conexão com a internet");
        }catch (Exception e){
            e.printStackTrace();
            retorno.setStatus(false);
            retorno.setMsg("Erro inesperado");
        }

        return retorno;
    }

    private static String converterInputStreamToString(InputStream is) throws Exception{
        StringBuffer buffer = new StringBuffer();

        BufferedReader br;
        String linha;

        br = new BufferedReader(new InputStreamReader(is));
        while((linha = br.readLine())!=null){
            buffer.append(linha);
        }

        br.close();

        return buffer.toString();
    }
}

