package rvs.com.br.loginaluno;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    protected String getWsPath(){
        SharedPreferences sharedPreferences =
                getSharedPreferences(getString(R.string.webservice_path_key), Context.MODE_PRIVATE);
        String result = sharedPreferences.getString(getString(R.string.webservice_path_value), "");
        //if (result == null || result.isEmpty()){
            result = getString(R.string.webservice_path_default);
        //}
        return result;
    }

    protected void setWsPath(String value){
        SharedPreferences sharedPreferences =
                getSharedPreferences(getString(R.string.webservice_path_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(getString(R.string.webservice_path_value), value);
        editor.apply();
    }

    protected String resetWsPath(){
        String defaultPath = getString(R.string.webservice_path_default);
        setWsPath(defaultPath);
        return defaultPath;
    }
}
