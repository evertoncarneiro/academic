package rvs.com.br.loginaluno;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //habilita botao home no canto superior esquerdo
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        final EditText editTextWsPath = (EditText) findViewById(R.id.url_webservice);
        editTextWsPath.setText(getWsPath());

        Button mSettings = (Button) findViewById(R.id.save_button);
        mSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setWsPath(editTextWsPath.getText().toString());
                Toast.makeText(getBaseContext(), "Sucesso ao salvar a URL do webservice!", Toast.LENGTH_LONG).show();
            }
        });

        Button mClean = (Button) findViewById(R.id.clean_button);
        mClean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextWsPath.setText(resetWsPath());
                Toast.makeText(getBaseContext(), "Sucesso ao reiniciar a URL do webservice!", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
